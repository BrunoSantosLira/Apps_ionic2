import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Geolocation } from '@capacitor/geolocation';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
dados= {
  cidade: ''
}

item1 = {}


temperatura = ''
nome = ''
umidade = ''
wind_speed = ''
icone = ''

  constructor() { }

  async ngOnInit() {
    const locale =  await Geolocation.getCurrentPosition()
    console.log(locale)

    const latitude = locale['coords'].latitude
    const longitude = locale['coords'].longitude

    const resposta = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&lang=pt_br&dt=1643803200&appid=69846968598a1f2b7b518936c1921345`)

    if(resposta.status == 200){
      const dados = await resposta.json()
      console.log(dados)
      this.temperatura = dados['main']['temp']
      this.nome = dados['name']
      this.umidade = dados['main']['humidity'];
      this.wind_speed = dados['wind']['speed']
      this.icone = `https://openweathermap.org/img/wn/${dados['weather'][0]['icon']}@4x.png` 
    }

  }

  async enviar(form: NgForm){

    const cidade = form.value.cidade
    console.log(cidade)

    const resposta = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cidade}&units=metric&lang=pt_br&dt=1643803200&appid=69846968598a1f2b7b518936c1921345`)
    
    if(resposta.status == 200){
      const dados = await resposta.json()
      console.log(dados)
      this.temperatura = dados['main']['temp']
      this.nome = dados['name']
      this.umidade = dados['main']['humidity'];
      this.wind_speed = dados['wind']['speed']
      this.icone = `https://openweathermap.org/img/wn/${dados['weather'][0]['icon']}@4x.png` 
    }

   
  }
}

