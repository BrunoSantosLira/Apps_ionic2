import { Component, OnInit } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-botao',
  templateUrl: './botao.page.html',
  styleUrls: ['./botao.page.scss'],
})
export class BotaoPage implements OnInit {

  constructor(public nav: NavController, private toastCtrl: ToastController) { }

  ngOnInit() {
  }

  abrirPagina(pag: string){
    this.nav.navigateForward(pag);
  }

  async metodoToast(position: 'top' | 'middle' | 'bottom') {
    const toast = await this.toastCtrl.create({
      message: 'Olá mundo!',
      duration: 2000,
      position: position,
    });

    await toast.present();
  }

}
