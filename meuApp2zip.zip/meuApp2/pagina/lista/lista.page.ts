import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.page.html',
  styleUrls: ['./lista.page.scss'],
})
export class ListaPage implements OnInit {
  personas = [
    {
      nome : "Bill Gates",
      url : "https://veganbusiness.com.br/wp-content/uploads/2019/03/mundo-mais-vegano-760x498.jpg",
      estrelas: 4
    },
    {
      nome: 'Steve Jobs',
      url: "https://t.ctcdn.com.br/WXGIAsXxAX1C2Qy2rqN4eoWyVCg=/400x400/smart/i490761.jpeg",
      estrelas: 5
    }
  ]

  constructor() { }

  ngOnInit() {
  }

}
