import { Component, OnInit } from '@angular/core';
import { ActionSheetController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-alertas',
  templateUrl: './alertas.page.html',
  styleUrls: ['./alertas.page.scss'],
})
export class AlertasPage implements OnInit {
nome = 'Bruno'
result = ''
  constructor(private alertController: AlertController, public as: ActionSheetController) { }

  ngOnInit() {
  }


  async abrirAlerta(){
    console.log('oi')
    const alert = await this.alertController.create({
      header: 'Alerta',
      message: 'Qual o seu nome?',
      inputs : [
        {
          name: 'name1', 
          type: 'text',
          placeholder: 'Nome',
        }
      ],
      buttons: [{
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          console.log('Você apertou em cancelar')
        },
      },
      {
        text: 'Ok',
        role: 'confirm',
        handler: (dados) => {
          console.log(dados)
          this.nome = dados.name1
        },
      },],
    });

    await alert.present();
  }

  async apresentarActionSheet() {
    const actionSheet = await this.as.create({
      header: 'Ação',
      buttons: [
        {
          text: 'Deletar',
          role: 'destructive',
          handler() {
            console.log('oii')
          },
        },
        
        {
          text: 'Inserir',
          role: 'add',
          handler() {
            console.log('ITEM ADICIONADO')
          },
        },
      ],
    });

    await actionSheet.present();

    const result = await actionSheet.onDidDismiss();
    this.result = JSON.stringify(result, null, 2);
  }
}

